
// BOM
// alert()  confirm() prompt()
 function Samra(){
   
    //  window.alert()
    // let myname="Siddharth Israni"
    //  alert(myname)

    // let myans=  confirm("Kya tum thik ho")
    // console.log(myans);

    //  let myans= prompt("What is your name")
    //   alert(myans)

    // =============if-else===========
    // if(condition){
    //     statement
    // }else{
    //     statement
    // }
        
    // let age= prompt("Please enter your age")

    //  if(age>=18){
    //     alert("You can vote")
    //  }
    //  else{
    //     alert("You can not vote")
    //  }


    let ans= confirm("DO you liked my website")

    if(ans){
        alert("Thank you")
    }
    else{
        alert("Bhaad me jao")
    }


    

 }

//  Samra()




 function Faiz(){

    //    alert("Hello i am Alert Message")

    //   let myans=  confirm("You are Okay")
    //   console.log(myans);

    // let myname=  prompt("What is your NAme")

    // alert(myname)
      

    //  let myans= prompt("Enter your age")

    //  if(myans>=18){
    //     alert("You can vote")
    //  }
    //  else{
    //     alert("You cant vote")
    //  }


    //  condition ? "on true" : "on false" 
    //  age>=18 ? alert("You can"): alert("You cant")


    //   let num1=  Number(prompt("Enter number 1"))
    //   let num2=  Number( prompt("Enter number 2"))
 

      // parseInt , parseFloat , Number

    //   alert(num1+num2)

    console.log(3+4+"5");
    
     
      for(let i=10 ; i >=1 ; i--){
        console.log(i);
        
      }


      1==='1'  // false


 }

 Faiz()





 function abc(){
  // let ans = confirm("you have comlete course")
  // let course = confirm("You have certificate")
  let name = prompt("Enter your name")
  alert("Hello " + name)

  // if(ans == true && course == true){
  //   alert("Yes you got job")
  // }
  // else{
  //   alert("you not get job")
  // }

 }
//  abc()
function Q9(){
  let num;
  do{
    num=prompt("Enter a number")
  }
  while(num<=10)
}
Q9()