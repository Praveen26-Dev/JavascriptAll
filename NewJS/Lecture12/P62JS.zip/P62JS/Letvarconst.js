   
   // var a=5
   // var b= null
   // var c=a-b

   // Type Corceion

//   1st priority String 
//   2nd priority Number

   // console.log(c);


//    2015 => ES6 

// var ,  let , const 


   // int main(){
    
        

   // }

   function Aniket(){

      // var a
      // int a , c ,b 

   //   var , let , const 

   //============ Redclaration=============
   //   var a=13
   //   var a=15 // allowed

   //   let b=14
   //   let b=42 // error mot allowed

   //   const c="adf"
   //   const c="dfb" // error mot allowed

   // =====================Re-assignment ==============
    
   //    var a=23
   //       a=24  // assignment allowed


   //    let b=34
   //       b=35  // assignment allowed
   //    //  console.log(b); 
       
   //    const c=25
   //        c=26  // assignment not allowed
   // console.log(c);
   

   //================ Scope =========== 
   // let a=5    
   // {

   //    let a=7
   //   console.log(a); // 7  error
     
   // }

   // console.log(a); // 5


   //========= Hoisting =======

   console.log(a); // error 5 

     let a=5
      
    
     

   

    
     
      


   }



   function Divyanshi(){

      console.log("Hello Divyanshi")
   }

   // Divyanshi()
   Aniket()
   