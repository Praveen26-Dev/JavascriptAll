 

 function Str() {
   
    //  let okk= "This isString"  // String 14   
    //  let okk2=" from Cybrom"  
    //  let okk3=" of Mp nagar" 
      
   //  alert(okk.length)  // 14 length
  //  console.log(okk.slice(6,12)); // i-S  6,12  6,13 
   //  console.log(okk.concat(okk2,okk3)); 
         
    // let okk="  this is string"

    // console.log(okk.length); // give normal with white space    
    // console.log(okk.trim().length); // give wihtout "" ""
    

   //  let str= "I am cyBrom From CybrOm"

   //  console.log(str.replace(/Cybrom/gi,"Bhopal"));
     

    // Array  
      // let fruits = ["Apple",3,true,"Banana"]  
    
      // let okkk= "Thisis String"
            

   //  console.log(okkk.split("-"));



    let myname= "Siddharth"
   //  console.log(myname.split("").reverse().join(""));    

   //  let rev=""

   //  for(let i=myname.length-1;i>=0;i--){
           
   //        rev+=myname[i]

   //  }
   //    console.log(rev);
      
   

      

 }

//  Str()



function Nadir(){

   alert("Hello i am Nadir")

}

function Riya(){

    
   //  Template letrals ( `` )

   // 1st use Supports single and double quotes
   // let okk =  `Hello i am 'From'  "Cybrom" of mp nagar`


   // 2nd use Supports Multi line Strings 
   // let okk= `Hello i am   
   //       ddgbkldgl jdnblknd   
   //     Cybrom of Mp nagar`

   // document.writeln("okkk from document")

   // let text= ` Hello <h1> Cybrom </h1> From Bhopal`
   // document.writeln(text)

   // 4th use Supports DYnamic Variabels 

    let myname= "Siddharth"
    let age= 26

   console.log( "Hello i am "+myname + " and i am " +age+" years old"   );
   console.log(` Hello i am ${myname} and i am ${age} years old  `);
   
   

   
   

 

}




// Riya()
// Nadir()