 

// //    alert("ytfyguyygb")

// //    let okk=  confirm("Are you Okk")

// //    if(okk==true){
// //        alert("okk")
// //    }else{
// //     alert("Dawai khalo")
// //    }

// // let ans1=  prompt("enter number 1")
// // let ans2=  prompt("enter number 2")

// // // parseInt parseFloat Number
// //   alert( parseInt(ans1)+ parseInt(ans2))


//   for(let i=10; i>=0;i--){

//     console.log(i);    

//   }

// //   condition?"on true":"on false"
//   let age=19
//   age%2==0?alert("you can vote"):alert("you cant")

//     //  if(condition){

    //     statement
    //  }
    //  else{
    //     statement
    //  }


    // condition ? "on true": "on false"
    // let agee=16
    
    // if(agee>=18){

    // }
    // else{
      
    // }
    // let agee= prompt("What is your age")
    // agee>=18? alert("you can vote"): alert("you cant")

    

    function okk(){

      //  1-10 
      // for(let i=10; i>=1 ; i-- ){

      //    console.log(i);
         
      // }

      // let i=0

      // while(i<=10){
      //   console.log(i);
      //   i++
        
      // }

      let a="Siddharth"

      // console.log(a[1]);
      

      // console.log(a.split("").reverse().join(""));
      let rev= ""

      for(let i=a.length-1; i>=0 ; i--){

            rev+=a[i]

      }

      console.log(rev);
      
   
             

    }

    okk()
    