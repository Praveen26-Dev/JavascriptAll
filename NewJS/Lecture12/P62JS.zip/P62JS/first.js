 

// int main(){

// }

//BOM 
// alert()  confirm()  prompt()

function okk(){

    //let const
    const a=6
        a=7
    console.log(a);
    
 

}
okk()
 