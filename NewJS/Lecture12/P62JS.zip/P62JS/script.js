//    'use strict'
    // int age=25 // 
    
       var age=25
       var name="Sid"

    //    cout<<age 
    console.log(age)
    console.log(name);
    


   